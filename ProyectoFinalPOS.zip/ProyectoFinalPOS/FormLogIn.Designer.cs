﻿
namespace ProyectoFinalPOS
{
    partial class FormLogIn
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxUsuario = new TextBox();
            textBoxPassword = new TextBox();
            buttonIngresar = new Button();
            pictureLogin = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureLogin).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // textBoxUsuario
            // 
            textBoxUsuario.Location = new Point(93, 251);
            textBoxUsuario.Name = "textBoxUsuario";
            textBoxUsuario.PlaceholderText = "Usuario";
            textBoxUsuario.Size = new Size(360, 27);
            textBoxUsuario.TabIndex = 1;
            // 
            // textBoxPassword
            // 
            textBoxPassword.Location = new Point(93, 307);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.PlaceholderText = "Contraseña";
            textBoxPassword.Size = new Size(360, 27);
            textBoxPassword.TabIndex = 2;
            // 
            // buttonIngresar
            // 
            buttonIngresar.BackColor = SystemColors.Control;
            buttonIngresar.Location = new Point(60, 362);
            buttonIngresar.Name = "buttonIngresar";
            buttonIngresar.Size = new Size(393, 38);
            buttonIngresar.TabIndex = 5;
            buttonIngresar.Text = "Ingresar";
            buttonIngresar.UseVisualStyleBackColor = false;
            buttonIngresar.Click += buttonIngresar_Click;
            // 
            // pictureLogin
            // 
            pictureLogin.Image = Properties.Resources.user_manage_114453;
            pictureLogin.Location = new Point(128, 24);
            pictureLogin.Name = "pictureLogin";
            pictureLogin.Size = new Size(262, 207);
            pictureLogin.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureLogin.TabIndex = 6;
            pictureLogin.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.user_icon_icons_com_57997;
            pictureBox1.Location = new Point(60, 251);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(27, 29);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.password_3715;
            pictureBox2.Location = new Point(60, 305);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(27, 29);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 8;
            pictureBox2.TabStop = false;
            // 
            // FormLogIn
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(519, 450);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(pictureLogin);
            Controls.Add(buttonIngresar);
            Controls.Add(textBoxPassword);
            Controls.Add(textBoxUsuario);
            Name = "FormLogIn";
            Text = "Iniciar Sesión";
            ((System.ComponentModel.ISupportInitialize)pictureLogin).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }


        #endregion
        private TextBox textBoxUsuario;
        private TextBox textBoxPassword;
        private Button buttonIngresar;
        private PictureBox pictureLogin;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
    }
}

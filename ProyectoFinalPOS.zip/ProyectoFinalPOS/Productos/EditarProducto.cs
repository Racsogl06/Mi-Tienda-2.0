﻿using ProyectoFinalPOS.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinalPOS.Productos
{
    public partial class EditarProducto : Form
    {
        Producto producto;
        public EditarProducto()
        {
            InitializeComponent();
            this.producto = producto;
        }

        private void EditarProducto_Load(object sender, EventArgs e)
        {
            textNombre.Text = producto.Nombre;
            textPrecio.Text = producto.Precio.ToString();
            textStock.Text = producto.Stock.ToString();
            textCodigo.Text = producto.Codigo.ToString();
            textDescripcion.Text = producto.Descripcion;
        }

        private void buttonActualizar_Click(object sender, EventArgs e)
        {
            {
                //AppState.Instance.posActual.EditarProducto(producto, new Producto(textNombre.Text, textDescripcion.Text, int.Parse(textPrecio.Text), int.Parse(textCodigo.Text), int.Parse(textStock.Text)));
            }
        }
    }
}

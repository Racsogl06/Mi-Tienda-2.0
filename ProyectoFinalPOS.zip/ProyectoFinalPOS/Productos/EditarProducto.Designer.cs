﻿namespace ProyectoFinalPOS.Productos
{
    partial class EditarProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            textNombre = new TextBox();
            textPrecio = new TextBox();
            textStock = new TextBox();
            textDescripcion = new TextBox();
            buttonActualizar = new Button();
            textCodigo = new TextBox();
            label7 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F);
            label1.Location = new Point(29, 33);
            label1.Name = "label1";
            label1.Size = new Size(346, 32);
            label1.TabIndex = 0;
            label1.Text = "Editar Información de Producto";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(42, 112);
            label2.Name = "label2";
            label2.Size = new Size(64, 20);
            label2.TabIndex = 1;
            label2.Text = "Nombre";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(42, 277);
            label3.Name = "label3";
            label3.Size = new Size(78, 20);
            label3.TabIndex = 2;
            label3.Text = "Fotografía";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(42, 219);
            label4.Name = "label4";
            label4.Size = new Size(45, 20);
            label4.TabIndex = 3;
            label4.Text = "Stock";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(42, 165);
            label5.Name = "label5";
            label5.Size = new Size(50, 20);
            label5.TabIndex = 4;
            label5.Text = "Precio";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(42, 342);
            label6.Name = "label6";
            label6.Size = new Size(87, 20);
            label6.TabIndex = 5;
            label6.Text = "Descripción";
            // 
            // textNombre
            // 
            textNombre.Location = new Point(146, 109);
            textNombre.Name = "textNombre";
            textNombre.PlaceholderText = "Escriba el nombre del Producto";
            textNombre.Size = new Size(283, 27);
            textNombre.TabIndex = 6;
            // 
            // textPrecio
            // 
            textPrecio.Location = new Point(146, 158);
            textPrecio.Name = "textPrecio";
            textPrecio.PlaceholderText = "Escriba el Precio del Producto";
            textPrecio.Size = new Size(283, 27);
            textPrecio.TabIndex = 7;
            // 
            // textStock
            // 
            textStock.Location = new Point(146, 219);
            textStock.Name = "textStock";
            textStock.PlaceholderText = "Escriba el Stock del Producto";
            textStock.Size = new Size(283, 27);
            textStock.TabIndex = 8;
            // 
            // textDescripcion
            // 
            textDescripcion.Location = new Point(146, 339);
            textDescripcion.Name = "textDescripcion";
            textDescripcion.PlaceholderText = "Escriba la Descripción del Producto";
            textDescripcion.Size = new Size(283, 27);
            textDescripcion.TabIndex = 9;
            // 
            // buttonActualizar
            // 
            buttonActualizar.Location = new Point(42, 500);
            buttonActualizar.Name = "buttonActualizar";
            buttonActualizar.Size = new Size(387, 42);
            buttonActualizar.TabIndex = 10;
            buttonActualizar.Text = "Actualizar";
            buttonActualizar.UseVisualStyleBackColor = true;
            // 
            // textCodigo
            // 
            textCodigo.Location = new Point(146, 390);
            textCodigo.Name = "textCodigo";
            textCodigo.PlaceholderText = "Escriba el código del Producto";
            textCodigo.Size = new Size(283, 27);
            textCodigo.TabIndex = 12;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(42, 390);
            label7.Name = "label7";
            label7.Size = new Size(58, 20);
            label7.TabIndex = 11;
            label7.Text = "Código";
            // 
            // EditarProducto
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(518, 619);
            Controls.Add(textCodigo);
            Controls.Add(label7);
            Controls.Add(buttonActualizar);
            Controls.Add(textDescripcion);
            Controls.Add(textStock);
            Controls.Add(textPrecio);
            Controls.Add(textNombre);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "EditarProducto";
            Text = "EditarProducto";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textNombre;
        private TextBox textPrecio;
        private TextBox textStock;
        private TextBox textDescripcion;
        private Button buttonActualizar;
        private TextBox textCodigo;
        private Label label7;
    }
}
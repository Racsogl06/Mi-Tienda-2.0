﻿using ProyectoFinalPOS.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinalPOS
{
    public partial class MantenimientoProducto : Form
    {
        public MantenimientoProducto()
        {
            InitializeComponent();
        }

        private void MantenimientoProducto_Load(object sender, EventArgs e)
        {

        }

        //private Panel crearTarjetaProducto(Producto producto)
        //{
        //    Panel panelTarjeta = new Panel();
        //    panelTarjeta.BorderStyle = BorderStyle.FixedSingle;
        //    panelTarjeta.Padding = new Padding(10);
        //    panelTarjeta.Margin = new Padding(10);
        //    panelTarjeta.BackColor = Color.LightGray;
        //    panelTarjeta.Size = new Size(200, 150);

        //    Label lblInfo = new Label();
        //    lblInfo.Text = $"{producto.Nombre} \n{producto.Descripcion} \n{producto.GetType().Name}";
        //    lblInfo.AutoSize = true;
        //    lblInfo.Font = new Font("Arial", 10, FontStyle.Regular);
        //    lblInfo.Padding = new Padding(5);

        //    Button btnEditar = new Button();
        //    btnEditar.Text = "Editar";
        //    btnEditar.AutoSize = true;
        //    btnEditar.Location = new Point(10, 100);
        //    btnEditar.Click += (sender, e) =>
        //}

        private void renderizarProdcutos()
        {
            //flowProductos.Controls.Clear();
            //AppState.Instance.posActual.productos.Where(producto => producto.Nombre.Contains(textBoxProducto.Text)).ToList().ForEach(producto =>
            //{
            //    flowProductos.Controls.Add(crearTarjetaProducto(producto));
            //});
            //flowProductos.AutoScroll = true;
        }
    }
}

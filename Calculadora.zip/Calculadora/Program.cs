﻿public class Calculadora
{
    public int Sumar(int a, int b)
    {
        return a + b;
    }
}
